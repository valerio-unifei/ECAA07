from flask import Flask # classe de aplicação web em flask
from flask import render_template # utiliza modelos em páginas web
from flask import redirect # redireciona o navegador para outra url
from flask import url_for # gera a url de uma rota do flask
from flask import request # coleta as variáveis passadas pelo navegador
from flask import flash # envia um valor de retorno para o conteúdo da página
from werkzeug.security import generate_password_hash # gera um hash criptografado de uma senha
from werkzeug.security import check_password_hash # compara hashs de senha atual e gravada
from flask_sqlalchemy import SQLAlchemy # classe getora de banco de dados 
from flask_login import UserMixin # modelo de usuário para login
from flask_login import LoginManager # classe gerenciadora de login para automação
from flask_login import login_required # indica rotas que necessitam de login para entrar
from flask_login import login_user # grava o usuário que logou na sessão
from flask_login import current_user # obtem usuário logado na sessão
from flask_login import logout_user # apaga usuário logado da sessão
from os import urandom # gerador de código aleatório para chave de segurança
from datetime import datetime # data e hora

# cria a aplicação web e pasta com modelos de páginas
app = Flask('PIMS UNIFEI', template_folder='templates')
# chave única do site para assinatura dos cookies
app.config['SECRET_KEY'] = urandom(12)
# modo debug
app.config["DEBUG"] = True

# gerenciamento de banco de dados
db = SQLAlchemy()
# indica banco de dados da aplicação em sqlite3
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///pims.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False # tira notificações do db
#conecta gerenciador de banco na aplicação
db.init_app(app)

# modelo para objeto usuário no banco
class Usuario(UserMixin, db.Model):
  id = db.Column(db.Integer, primary_key=True)
  usuario = db.Column(db.String(255))
  email = db.Column(db.String(150), unique=True)
  senha = db.Column(db.String(300))
  criado = db.Column(db.DateTime)
  
# gestão de login automatizada
login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)

@login_manager.user_loader
def load_user(usuario_id):
  # guarda a chave primária do usuário após login
  return Usuario.query.get(int(usuario_id))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/signup')
def signup():
    return render_template('signup.html')
    
@app.route('/signup', methods=['POST'])
def signup_post():
    email = request.form.get('email')
    usuario = request.form.get('name')
    senha = request.form.get('password')
    # verifica se o usuário já existe no banco
    user = Usuario.query.filter_by(email = email).first() 
    # se existe rediciona a criação para tentar novamente com outro usuário
    if user:
        flash('E-mail de usuário já existe no site')
        return redirect(url_for('signup'))
    # montando dados do usuário para salvar no banco
    new_user = Usuario(
        email = email, 
        usuario = usuario, 
        senha = generate_password_hash(senha, method='sha256'),
        criado = datetime.now(),
        )
    #  inserindo o usuário no banco de dados
    db.session.add(new_user)
    db.session.commit()
    return redirect(url_for('login'))

@app.route('/login', methods=['POST'])
def login_post():
    email = request.form.get('email')
    senha = request.form.get('password')
    remember = True if request.form.get('Lembre-me') else False
    user = Usuario.query.filter_by(email=email).first()
    # se usuário ou hash da senha não são iguais ao do banco
    if not user or not check_password_hash(user.senha, senha):
        flash('Usuário ou senha incorretos')
        return redirect(url_for('login'))
    #cadastra usuário na memória da sessão
    login_user(user, remember=remember)
    # se tudo ok, redireciona a página principal
    return redirect(url_for('profile'))

@app.route('/profile')
@login_required # proteção de entrada com login
def profile():
    # redireciona a página do usuário com 
    return render_template('profile.html', user = current_user)

@app.route('/logout')
@login_required # proteção de entrada com login
def logout():
    # descadastra usuário da memória
    logout_user() 
    # rediciona a página inicial da aplicação
    return redirect(url_for('index'))